package com.accenture.model;


public class Marche {
	private  int venta;
	private String vente;
	private double somme;
	private double total;
	public String getVente() {
		return vente;
	}

	public void setVente(String vente) {
		this.vente = vente;
	}

	
	
	
	public double getSomme() {
		return somme;
	}

	public void setSomme(double somme) {
		this.somme = somme;
	}

	public int getVenta() {
		return venta;
	}

	public void setVenta(int venta) {
		this.venta = venta;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}
	

}
